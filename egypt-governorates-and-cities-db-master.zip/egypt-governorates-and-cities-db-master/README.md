# Egypt Governorates and Cities DB

قاعدة بيانات محافظات و مدن مصر

### Added 396 Cities of Egypt